from setuptools import setup

setup(

    name = "paquetecalculos",
    version = 1.0,
    description = "Paquete de redondeo y potencia",
    author = "Rodrigo",
    author_email = "rodrigoa_rp@hotmail.com",
    packages = ["PI_calculos", "PI_calculos.redondeo_potencia"]


)