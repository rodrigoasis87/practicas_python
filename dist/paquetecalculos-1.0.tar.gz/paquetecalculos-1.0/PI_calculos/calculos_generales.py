def sumar(op1, op2):
    print(op1 + op2)

def restar(op1, op2):
    print(op1 - op2)

def multiplicar(op1, op2):
    print(op1 * op2)

def dividir(dividendo, divisor):
    print(dividendo / divisor)

def potencia(base, exponente):
    print(base ** exponente)

def redondear(numero):
    print(round(numero))