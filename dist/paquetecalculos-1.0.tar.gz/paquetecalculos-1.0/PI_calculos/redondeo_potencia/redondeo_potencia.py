def potencia(base, exponente):
    print(base ** exponente)

def redondear(numero):
    print(round(numero))